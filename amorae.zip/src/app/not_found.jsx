import React from 'react';

const not_found = () => {
    return (
        <div>
            Not Found
        </div>
    );
};

export default not_found;