import React from 'react';

const page = () => {
    return (
        <div>
            my bookings
        </div>
    );
};

export default page;